While the VirtualBox guest additions does not officially support NT 3.x some
of the core drivers and tools happens to work.  However, the installer binary
(VBoxWindowsAdditions-x86.exe) does not run on anything older than NT 4,
makeing it hard to extract (VBoxWindowsAdditions-x86.exe /extract /D=C:\dir)
the necessary files.  So, the 32-bit drivers and components that might work
on NT 3.x are provided here for convenience.
